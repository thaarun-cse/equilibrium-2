# Equilibrium – Personal Expense & Budget Tracker (C)

## Run locally (test only)
    gcc -O2 -o equilibrium equilibrium.c
    ADMIN_USER=yourname ADMIN_PASS=YourStrongPass ./equilibrium     # http://localhost:8080

## Put it online for free (Render.com, no localhost)
1. Create a free GitHub account + a new repository; upload `equilibrium.c` and `Dockerfile`.
2. On render.com sign up free -> New -> Web Service -> connect that repo (Runtime: Docker, Instance: Free).
3. Under Environment add:  ADMIN_USER = yourname   ADMIN_PASS = a strong password (6+ chars)
4. Deploy. You get a public https://xxxx.onrender.com link to share with everyone.

Log in with ADMIN_USER / ADMIN_PASS to get the Admin page (view and delete users).
Everyone else uses "Register" on the home page.
